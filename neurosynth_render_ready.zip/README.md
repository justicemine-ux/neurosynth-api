# Neurosynth API — Render assignment

Based on [Tren ns-nano](https://github.com/spiketren/ns-nano). The original `app.py` from Tren only implements placeholder term/location handlers; this version implements study-level A minus B queries over the database schema produced by Tren's `create_db.py`.

## What is here

- `app.py`: Flask public API.
- `create_db.py`: Tren Parquet-to-PostgreSQL loader, with a small connection string compatibility fix for psycopg2 COPY.
- `coordinates.parquet`, `annotations.parquet`, `metadata.parquet`: user-provided original datasets.
- `.github/workflows/import-neurosynth.yml`: manually launched GitHub Actions importer, so no Python installation on your Windows PC.
- `requirements.txt`: Render website runtime.
- `requirements-import.txt`: dependencies for GitHub Actions loader.

## Complete the existing deployment (no new accounts)

1. Open your EXISTING GitHub repo `justicemine-ux/neurosynth-api`. Upload the **contents of this folder** into its root, overwriting existing files where needed. Include the three `.parquet` files and `.github/workflows/import-neurosynth.yml` (GitHub may require uploading the hidden `.github` directory separately via Add file > Create new file, with path `.github/workflows/import-neurosynth.yml`). The web UI may not preserve hidden folders during drag/drop; verify `.github/workflows` exists afterwards.
2. In your Render PostgreSQL database choose **External Database URL**, copy it without publishing it. In GitHub repository go to **Settings > Secrets and variables > Actions > New repository secret**. Name it `RENDER_EXTERNAL_DB_URL` and paste the external URL as its value. **Do NOT paste secrets in GitHub files or into chat.** Confirm Render database allows external access from GitHub-hosted runners. The Internal Database URL will not work from GitHub Actions.
3. GitHub repo **Actions > Import Neurosynth into Render Postgres > Run workflow**, then read the log for green check / errors. It can take time and may hit the free Postgres storage limit (1GB). Do not continuously rerun after a partial failure without checking remaining database space.
4. Render Web Service already uses `DB_URL` = its **Internal Database URL**. Make sure Render deploys the new code. Build command `pip install -r requirements.txt`; start command `gunicorn app:app --bind 0.0.0.0:$PORT`. The web runtime should not install pandas/pyarrow.
5. Test `https://neurosynth-api-4ge9.onrender.com/test_db` — must return `ok:true` with three positive counts; and:
   - `https://neurosynth-api-4ge9.onrender.com/dissociate/terms/fear/memory`
   - `https://neurosynth-api-4ge9.onrender.com/dissociate/locations/0_-52_26/-2_50_-6`

## Notes / constraints

- This bundle has undergone static Python validation, but **no live import or hosted database test has been performed** here. You still need to run the Action and verify the outputs before submitting.
- Public app `/health` only checks the process, not the research database. `/test_db` is the readiness check.
- Keep credentials in GitHub Actions secrets and Render Environment only.
- The GitHub Actions workflow uses user-provided Parquet data. Github repository public visibility means these data files would be public; the upstream repo already distributes these files, but verify course licensing.
- The provided import script may require more than 1 GB of PostgreSQL storage, depending on the expanded annotation terms. If the Action fails with out-of-disk-space, a larger database or a revised import strategy will be needed.

## Endpoints

`/health`, `/test_db`, `/img`, `/terms/<term>/studies`, `/locations/<x_y_z>/studies`, `/dissociate/terms/<a>/<b>`, `/dissociate/locations/<x_y_z>/<x_y_z>`.
